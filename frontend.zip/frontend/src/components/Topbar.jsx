import { useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import {
  FaBell,
  FaSearch,
  FaUserCircle,
} from "react-icons/fa";

function Topbar() {
  const [time, setTime] = useState(new Date());
  const location = useLocation();

  useEffect(() => {
    const timer = setInterval(() => {
      setTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const menuItems = [
    {
      title: "Dashboard",
      path: "/manager-dashboard",
    },
    {
      title: "Restaurants",
      path: "/restaurants",
    },
    {
      title: "Inventory",
      path: "/inventory",
    },
    {
      title: "Orders",
      path: "/orders",
    },
    {
      title: "Menu",
      path: "/menu",
    },
    {
      title: "Reservations",
      path: "/reservations",
    },
    {
      title: "Employees",
      path: "/employees",
    },
    {
      title: "Reports",
      path: "/reports",
    },
    {
      title: "Predictions",
      path: "/predictions",
    },
  ];

  return (
    <header
      style={{
        position: "sticky",
        top: 0,
        zIndex: 999,
        height: "85px",
        background: "rgba(15,15,20,.90)",
        backdropFilter: "blur(16px)",
        borderBottom: "1px solid rgba(255,255,255,.08)",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        padding: "0 28px",
      }}
    >
      {/* Left */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: "30px",
        }}
      >
        <h2
          style={{
            margin: 0,
            color: "#22C55E",
            fontWeight: "800",
            whiteSpace: "nowrap",
          }}
        >
          🍽 Cloud Restaurant
        </h2>

        <div
          style={{
            display: "flex",
            gap: "10px",
            flexWrap: "wrap",
          }}
        >
          {menuItems.map((item) => {
            const active =
              location.pathname === item.path;

            return (
              <Link
                key={item.path}
                to={item.path}
                style={{
                  textDecoration: "none",
                  padding: "10px 16px",
                  borderRadius: "12px",
                  fontSize: "15px",
                  fontWeight: "600",
                  color: active
                    ? "#fff"
                    : "#CBD5E1",
                  background: active
                    ? "linear-gradient(90deg,#2563EB,#7C3AED)"
                    : "rgba(255,255,255,.04)",
                  transition: ".3s",
                }}
                onMouseEnter={(e) => {
                  if (!active) {
                    e.currentTarget.style.background =
                      "rgba(255,255,255,.08)";
                  }
                }}
                onMouseLeave={(e) => {
                  if (!active) {
                    e.currentTarget.style.background =
                      "rgba(255,255,255,.04)";
                  }
                }}
              >
                {item.title}
              </Link>
            );
          })}
        </div>
      </div>

      {/* Right */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: "18px",
        }}
      >
        {/* Search */}

        <div
          style={{
            display: "flex",
            alignItems: "center",
            background:
              "rgba(255,255,255,.05)",
            border:
              "1px solid rgba(255,255,255,.08)",
            borderRadius: "14px",
            padding: "10px 15px",
          }}
        >
          <FaSearch
            color="#9CA3AF"
            style={{
              marginRight: "10px",
            }}
          />

          <input
            type="text"
            placeholder="Search..."
            style={{
              background: "transparent",
              border: "none",
              outline: "none",
              color: "#fff",
              width: "170px",
              fontSize: "14px",
            }}
          />
        </div>

        {/* Date */}

        <div
          style={{
            textAlign: "right",
            color: "white",
          }}
        >
          <div
            style={{
              fontWeight: "600",
            }}
          >
            {time.toLocaleDateString()}
          </div>

          <div
            style={{
              color: "#9CA3AF",
              fontSize: "12px",
            }}
          >
            {time.toLocaleTimeString()}
          </div>
        </div>

        {/* Bell */}

        <div
          style={{
            width: "42px",
            height: "42px",
            borderRadius: "50%",
            background:
              "rgba(255,255,255,.05)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            cursor: "pointer",
          }}
        >
          <FaBell color="white" />
        </div>

        {/* User */}

        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "10px",
            padding: "8px 15px",
            background:
              "rgba(255,255,255,.05)",
            borderRadius: "14px",
          }}
        >
          <FaUserCircle
            size={38}
            color="#3B82F6"
          />

          <div>
            <div
              style={{
                color: "white",
                fontWeight: "600",
              }}
            >
              Restaurant Admin
            </div>

            <div
              style={{
                color: "#9CA3AF",
                fontSize: "12px",
              }}
            >
              Manager
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}

export default Topbar;