import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Tooltip,
  Legend,
} from "chart.js";

import {
  Line,
  Bar,
  Doughnut,
} from "react-chartjs-2";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Tooltip,
  Legend
);

function PredictionChart({ predictions = [] }) {
  if (!predictions.length) {
    return (
      <div
        style={{
          color: "white",
          textAlign: "center",
          padding: "40px",
        }}
      >
        No Prediction Data
      </div>
    );
  }

  const labels = predictions.map(
    (item) => item.item
  );

  const stockData = predictions.map(
    (item) => item.currentStock
  );

  const reorderData = predictions.map(
    (item) => item.recommendedOrder
  );

  const daysData = predictions.map(
    (item) => item.daysRemaining
  );

  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns:
          "repeat(auto-fit,minmax(420px,1fr))",
        gap: "35px",
      }}
    >
      {/* Line Chart */}

      <div
        style={{
          background: "#1F2937",
          borderRadius: "18px",
          padding: "20px",
        }}
      >
        <h3
          style={{
            color: "white",
            textAlign: "center",
          }}
        >
          Inventory Levels
        </h3>

        <Line
          data={{
            labels,
            datasets: [
              {
                label: "Current Stock",
                data: stockData,
              },
            ],
          }}
        />
      </div>

      {/* Bar Chart */}

      <div
        style={{
          background: "#1F2937",
          borderRadius: "18px",
          padding: "20px",
        }}
      >
        <h3
          style={{
            color: "white",
            textAlign: "center",
          }}
        >
          Reorder Quantity
        </h3>

        <Bar
          data={{
            labels,
            datasets: [
              {
                label: "Reorder",
                data: reorderData,
              },
            ],
          }}
        />
      </div>

      {/* Doughnut */}

      <div
        style={{
          background: "#1F2937",
          borderRadius: "18px",
          padding: "20px",
        }}
      >
        <h3
          style={{
            color: "white",
            textAlign: "center",
          }}
        >
          Stock Distribution
        </h3>

        <Doughnut
          data={{
            labels,
            datasets: [
              {
                data: stockData,
              },
            ],
          }}
        />
      </div>

      {/* Days Remaining */}

      <div
        style={{
          background: "#1F2937",
          borderRadius: "18px",
          padding: "20px",
        }}
      >
        <h3
          style={{
            color: "white",
            textAlign: "center",
          }}
        >
          Days Remaining
        </h3>

        <Bar
          data={{
            labels,
            datasets: [
              {
                label: "Days",
                data: daysData,
              },
            ],
          }}
        />
      </div>
    </div>
  );
}

export default PredictionChart;